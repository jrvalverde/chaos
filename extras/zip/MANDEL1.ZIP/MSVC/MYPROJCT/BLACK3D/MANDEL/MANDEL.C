#include <general.h>
#include <conio.h>  
#include <stdio.h>

void main (void)
{
float a, b, cx, cy, x0, y0, x1, y1, i, c;    
int index, done=0;
RGBPalette pal, sav;    
printf ("After the fractal is displayed, press any key to rotate the palette.\n"
        "During rotation push 'p' to generate a new palette or q to quit.");    
getch ();
SetGraphicsMode (0x13);   
for (a=0; a<=320; a++)
   {
   cx=-2+a/80;
   for (b=0; b<=200; b++)
      {       
      c=1;
      cy=2-b/50;
      x0=0;
      y0=0;
      for (i=1; i<=20; i++)
         {
         x1=x0*x0-y0*y0+cx;
         y1=2*x0*y0+cy;
         if ((x1*x1+y1*y1)>50)
            goto cont;
         x0=x1;
         y0=y1;
         c++;
         }       
      c=0;          
      cont:
      WritePixel (a, b, c);
      }
   }               
getch ();     
pal.colors[0].red = 0;
pal.colors[0].green = 0;
pal.colors[0].blue = 0;
while (!done)
   { 
   if (kbhit ())
      {
      switch (getch ())
         {
         case 'p':
            for (index=1; index<256; index++)
               {
               pal.colors[index].red = rand()%256;
               pal.colors[index].green = rand()%256;
               pal.colors[index].blue = rand()%256;
               }
            WritePalette (0, 255, (PRGBPalette)&pal);
            break;
         case 'q':
            done=1;
            break;
         default:
            break;
         }
      }   
   ReadPalette (0, 255, (PRGBPalette)&sav);
   pal.colors[255].blue = sav.colors[1].blue;
   pal.colors[255].green = sav.colors[1].green;
   pal.colors[255].red = sav.colors[1].red;
   for (index=1; index<255; index++)
      {
      pal.colors[index].red = sav.colors[index+1].red;
      pal.colors[index].green = sav.colors[index+1].green;
      pal.colors[index].blue = sav.colors[index+1].blue;
      }       
   Delay (1);
   WritePalette (0, 255, (PRGBPalette)&pal);
   }
SetGraphicsMode (0x03); 
}
/*
	"Stubbed-Off" Routines and variables
	which exist only in Fractint for DOS
*/

#include "fractint.h"

/* not-yet-implemented variables */

double sxmin, sxmax, sx3rd, symin, symax, sy3rd;
int color_bright = 15;
int color_medium = 7;
int color_dark = 0;
int hasinverse = 0;
char diskfilename[] = {"FRACTINT.$$$"};
BYTE	 *line_buff;
char *fract_dir1=".", *fract_dir2=".";
int Printer_Compress;
int keybuffer;
int LPTnumber;
int ColorPS;
int Print_To_File;
int Printer_Type;
int Printer_CRLF;
int Printer_Resolution;
int Printer_Titleblock;
int Printer_ColorXlat;
int Printer_BAngle;
int Printer_GAngle;
int Printer_SAngle;
int Printer_RAngle;
int Printer_RFrequency;
int Printer_GFrequency;
int Printer_BFrequency;
int Printer_SFrequency;
int Printer_SetScreen;
int Printer_RStyle;
int Printer_GStyle;
int Printer_BStyle;
int Printer_SStyle;
int EPSFileType;
int integerfractal;
int video_type;
int adapter;
int usr_periodicitycheck;
int active_system = WINFRAC;	/* running under windows */
char busy;
int mode7text;
int textsafe;
int iit = 0;
long calctime;
char stdcalcmode;
int compiled_by_turboc = 0;
int tabmode;
double plotmx1, plotmx2, plotmy1, plotmy2;
int vesa_detect;
long creal, cimag;
int TranspSymmetry;
long fudge;
long	l_at_rad;		/* finite attractor radius  */
double	f_at_rad;		/* finite attractor radius  */
int timedsave = 0;
int made_dsktemp = 0;
int reallyega = 0;
int started_resaves = 0;
float viewreduction=1;
int viewxdots=0,viewydots=0;
int usr_floatflag;
int disk16bit = 0;
double potparam[3];
int gotrealdac = 1;
int svga_type = 0;
int viewcrop=1;
int viewwindow=0;

/* fake/not-yet-implemented subroutines */

void rotate(int x) {}
void find_special_colors() {}
int spawnl() {return 0;}
int showtempmsg(char *foo) {return 1;}
void cleartempmsg() {}
void freetempmsg() {}
int FromMemDisk(long offset, int size, void far *src) {return 0;}
int ToMemDisk(long offset, int size, void far *src) {return 0;}
int  common_startdisk(long newrowsize, long newcolsize, int colors) { return 0;}
long cdecl normalize(char far *foo) { return 0;}
void drawbox(int foo) {}

void farmessage(unsigned char far *foo) {}
void setvideomode(int foo1, int foo2, int foo3, int foo4) {}
int fromvideotable() {}
int home() {}

int intro_overlay() {}
int rotate_overlay() {}
int printer_overlay() {}
int pot_startdisk() {}
int SetTgaColors() {}
int startdisk() {}
int enddisk() {}
int readdisk() {}
int writedisk() {}
int nosnd(){}
int snd(){}
int targa_startdisk(){}
int targa_writedisk(){}
int targa_readdisk(){}
int SetColorPaletteName() {}
int findfont() {return(0);}
int readticker(){return(0);}
int EndTGA(){}

int dvid_status(){}
int tovideotable(){}

void load_mat(){}
void mult_vec_iit(){}

void TranspPerPixel(){}

void stopslideshow() {}
void aspectratio_crop() {}
void setvideotext() {}
void load_fractint_cfg() {}

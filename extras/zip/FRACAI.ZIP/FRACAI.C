#include <graph.h>
#include <dos.h>
#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

double i, j, iInit, jInit, Temp, OffsetX = -0.5, OffsetY = 0.0, Scale = 0.35;
double AspectX, AspectY;
int LastPeriod, NumRep, CheckEvery, Periodicity, RequiredRep = 5;
int Lastx, Lasty, Midx, Midy, x, y, n;

/* To make this program stupid, change the IQ to zero */
int IQ = 1;

void ResetAI(void) {
   Lastx = Lasty = NumRep = 0;
   Periodicity = LastPeriod = 1;  /* First assume a periodicity of 1 */
   CheckEvery = 3;                /* Look for small patterns first */
}
void ResetAI(void);

int Check(void) {
   /* Convert 'i' & 'j' to screen coord */
   x = (short)((long)((i - OffsetX) / AspectX));
   y = (short)((long)((j - OffsetY) / AspectY));


   /* Check for overflow */
   if((x > 1000) || (x < -1000) || (y > 1000) || (y < -1000))
      return(n);

   /* XOR pixel to screen */
   if(x || y) {
		_setcolor(_getpixel(x, y) ^ 15);
      _setpixel(x, y);
   }

   /* Am I supposed to be intellegent about this? */
   if(IQ == 0)

      /* Nope.  Act stupid and keep iterating! */
      return(0);

   /* Is this point the same as the one I sampled earlier? */
   if((x == Lastx) && (y == Lasty)) {

      /* Is the number of iterations between now and when I last
         saw this point the same as the time before? */
      if(LastPeriod == Periodicity) {

         /* Has this pattern repeated itself 'RequiredRep' times? */
         if(NumRep++ == RequiredRep)
            return(Periodicity);  /* Yep, return the periodicity */
      }

      /* Nope, keep looking - maybe is will settle out */
      else {
         LastPeriod = Periodicity;
         Periodicity = 1;
      }
   }

   /* Time to pick a new sample point? */
   else {
		if(Periodicity++ >= CheckEvery) {
			CheckEvery *= 2;  /* Look for larger patterns */
         Periodicity = 1;
         Lastx = x;
         Lasty = y;
         NumRep = 0;
      }
   }
   return(0);
}
int Check(void);

int ChkPoint(void) {
   int Ret;

   i = iInit;
   j = jInit;
   ResetAI();
   n = 1;
	for(n = 1; (n <2000); n++) {
      Temp = (i * i) - (j * j);
      j = (2 * i * j) + jInit;
      i = Temp + iInit;
      Ret = Check();
      if(Ret)
         return(Ret);
   }
   return(14);
}
int ChkPoint(void);

void PlotPoint(int x, int y) {
   iInit = (AspectX * x) + OffsetX;
   jInit = (AspectY * y) + OffsetY;
   ChkPoint();
   n = ChkPoint();
   if(n > 14)
      n = 14;
   _setcolor(n);
   _setpixel(x, y);
}

void main(void) {
	int Done = 0;
   struct videoconfig Vid;
   union REGS Regs;

   if(!_setvideomode(_VRES16COLOR)) {
      if(!_setvideomode(_ERESCOLOR)) {
         printf("Sorry, EGA or VGA required\n");
         exit(1);
      }
   }

   _getvideoconfig(&Vid);
   Midx = Vid.numxpixels / 2;
   Midy = Vid.numypixels / 2;
   _setlogorg(Midx, Midy);

   AspectX = (Scale * 10.0) / Vid.numxpixels;
   AspectY = (Scale * 7.0) / Vid.numypixels;
   OffsetX += 1.0 / Vid.numxpixels;
   OffsetY += 1.0 / Vid.numypixels;
   while(!Done) {
      x = (int)((((long)rand() * Vid.numxpixels) / 32767) - Midx);
      y = (int)((((long)rand() * Vid.numxpixels) / 32767) - Midy);
      if(!_getpixel(x, y))
         PlotPoint(x, y);
      if(kbhit())
         Done = (getch() == 27);
   }
   _setvideomode(_DEFAULTMODE);
}

